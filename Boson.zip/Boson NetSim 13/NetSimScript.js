function getInternetExplorerVersion()
// Returns the version of Windows Internet Explorer or a -1
// (indicating the use of another browser).
{
   var rv = -1; // Return value assumes failure.
   if (navigator.appName == 'Microsoft Internet Explorer')
   {
      var ua = navigator.userAgent;
      var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
      if (re.exec(ua) != null)
         rv = parseFloat( RegExp.$1 );
   }
   return rv;
}
function checkIEVersion()
{
   var msg = "You're not using Windows Internet Explorer.";
   var ver = getInternetExplorerVersion();
   var doc = document.documentElement;
   //if you have Edge version will come back -1
   if(ver>10||ver==-1){
   		doc.setAttribute('class',"NewIE")
   }else{
   		doc.setAttribute('class',"OldIE")
   }
}
checkIEVersion()
var TitleHeader = document.getElementById("lab-title");
document.getElementsByTagName("title")[0].textContent = TitleHeader.textContent;
document.oncontextmenu = function () { return false; }
document.ondragstart = function () { return false; }
document.onselectstart = function () { return false;}